function [A_hat,E_hat,G_hat,iter,stopCriterion] = ORLRS(X, p,c,alpha, theta,tol, maxIter)

addpath PROPACK;

[m,n] = size(X);

% if nargin < 2
%     alpha = 1 / sqrt(m);
% end

if nargin < 3
    tol = 1e-7;
elseif tol == -1
    tol = 1e-7;
end

if nargin < 4
    maxIter = 1000;
elseif maxIter == -1
    maxIter = 1000;
end

% initialize
Y = X;
norm_two = lansvd(Y, 1, 'L');
norm_inf = norm( Y(:), inf) / alpha;
dual_norm = max(norm_two, norm_inf);
Y = Y / dual_norm;

 I=eye(n);
 D=eye(n);
A_hat = X;
E_hat = zeros( m, n);
mu = 1.25/norm_two; 
mu_bar = mu * 1e7;
rho = 1.5;         
d_norm = norm(X, 'fro');


 a=zeros(n,c);
 Idx=kmeans(X',c);
 for i=1:n
     a(i,Idx(i,1))=1;
 end
 G_hat=a;

iter = 0;
total_svd = 0;
converged = false;
stopCriterion = 1;
sv = 10;
while ~converged       
    iter = iter + 1;
    
       %% Update A
    J1=X-E_hat+(1/mu)*Y;
     M1=2*p*(A_hat'*A_hat)^(p-1)+mu*I;
    A_hat=mu*J1/M1;
    
    %% Update E
    J2=X-A_hat+(1/mu)*Y;
    M2=2*alpha*D+mu*I;
    E_hat=mu*J2/M2;
    for i=1:n
        if norm(E_hat(:,i))<=theta
            D(i,i)=1/(2*norm(E_hat(:,i)));
        else
            D(i,i)=0;
        end
    end

    %% Updata G
    [G_hat] = NLRS(A_hat, G_hat,p,c);
    
    total_svd = total_svd + 1;
    
    Z = X - A_hat - E_hat;
    
    Y = Y + mu*Z;
    mu = min(mu*rho, mu_bar);
        
    %% stop Criterion    
    stopCriterion = norm(Z, 'fro') / d_norm;
    if stopCriterion < tol
        converged = true;
    end    
       disp(stopCriterion);
   
    
    if ~converged && iter >= maxIter
        disp('Maximum iterations reached') ;
        converged = 1 ;       
    end
end
