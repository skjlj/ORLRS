
function [Qd] = NLRS(X, Q,p,c)

r = 0.000000001;   % regularized Schatten p-Norm

k=2;
isdisc= 1;
isbias=0;
if p > 0.95
    inMaxIter = 50;
else
    inMaxIter = 50;
end;
[dim, n] = size(X);

obj = zeros(inMaxIter, 1);
if dim > n
    z = zeros(dim-n,1);
else
    z = [];
end;
b = zeros(dim,c);
for iter = 1: 1
    % fix Q, update D
    Qtr = 0;
    for g = 1:c
        XQ = (X-b(:,g)*ones(1,n))*diag(Q(:,g));
        [U,S,V] = svd(XQ);
        s = [diag(S); z]; 
        sv(:,g)=[sum(s); sum(s.^p); sum(s.^p)^k; s];
        s0 = sqrt(s.^2+r).^p;
        Qtrg = sum(s0);
        Qtr = Qtr + Qtrg^k;
        d = p/2*(sqrt(s.^2+r).^(p-2));
        D{g} = k*Qtrg^(k-1)*U*diag(d)*U'
    end
    
    % fix D, update Q
    for g = 1:c
        X1 = X-b(:,g)*ones(1,n);
        A(:,g) = diag(X1'*D{g}*X1);
    end
    if isdisc == 1
        [min_val, qMat] = min(A, [], 2);
        Q = zeros(n,c);
        for t = 1:n     
            Q(t, qMat(t)) = 1;
        end
    else
        for t = 1:n
        a = A(t,:);
        Q(t,:) = 1/sum(1./a)*1./a;
        end;
    end;
    
    % update b
    if isbias == 1
        QQ = Q.^2;
        b = (X*QQ)./((ones(dim,1)*sum(QQ))+eps);
    else
        b = zeros(dim,c);
    end;
    
    % calculate obj   
    obj(iter) = Qtr;
end

if isdisc == 1
    Qd = Q;
else
    [min_val, qMat] = max(Q, [], 2);
    Qd = zeros(n,c);
    for t = 1:n     
        Qd(t, qMat(t)) = 1;
    end
end;
1;




