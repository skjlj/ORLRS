clear all
clc
 %% AMLALLML
 load AMLALLML.mat;
 label=L;
 X=M;
 c=2; 
 X=mapstd(X')';
%% PCA    
    no_dims=15;
   [mappedX, mapping] = PCA(X,no_dims);
   X=mappedX';
   [m,n]=size(X);
%% ORLRS
alpha=0.1;
theta=10^6;
p=1;

tol=1e-7;
maxIter=30;

[A,E,G,iter,stopCriterion] = ORLRS(X, p,c,alpha, theta,tol, maxIter);
